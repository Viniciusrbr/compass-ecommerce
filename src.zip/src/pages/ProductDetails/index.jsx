import React from "react";

function ProductDetailsPage() {
  return <div>ProductDetailsPage</div>;
}

export default ProductDetailsPage;
