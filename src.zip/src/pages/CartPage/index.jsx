import React from 'react'


function CartPage() {
  return (
    <div>CartPage</div>
    )
}

export default CartPage
