import React from 'react'
import styled from 'styled-components';


const FooterContainer = styled.div`
  background-color: #1D1F1F;
  padding: 20px;
  text-align: center;
`;

const FooterText = styled.p`
  margin: 10px 0;
`;

const CopyrightText = styled.p`
  margin-top: 20px;
  font-size: 12px;
`;

function Footer() {
  return (
    <><FooterContainer>
      <FooterText>Baixe nosso app</FooterText>
      <FooterText>Você pode cancelar a inscrição a qualquer momento</FooterText>
      <FooterText>Assine a newsletter</FooterText>
    </FooterContainer>
      <CopyrightText>
        <CopyrightText>© 2023 Todos os direitos reservados</CopyrightText>
      </CopyrightText></>

  );
}

export default Footer;